KUNDALIYA DRONE COVERAGE BALANCE - FIELD PACKAGE
Analysis date: 25 November 2026
Latest source flight date: 2026-11-18

Estimated results
- R3 AOI: 8,297.73 ha
- Provisionally covered: 8,195.56 ha (98.77%)
- Balance for field planning: 102.17 ha (1.23%)
- Additional non-overlap area contributed after sortie 160: 3,463.59 ha

Use the mission balance CSV/KML to sequence field work. Missions below 95% estimated coverage remain flagged for verification or balance flying.

Important limitation
These are raw-image acquisition estimates based on per-sortie image-centre convex hulls buffered by 100 m. They are not certified camera footprints, accepted orthomosaic coverage, or contractual measured area. Final acceptance must use processed imagery and valid output rasters.
